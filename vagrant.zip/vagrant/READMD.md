# Date: 3/10/2017
# How to shutdown a vagrant box
cd <vagrant env>
vagrant halt <box>

